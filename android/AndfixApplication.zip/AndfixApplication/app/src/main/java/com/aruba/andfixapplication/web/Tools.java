package com.aruba.andfixapplication.web;

import com.aruba.andfixapplication.Replace;

/**
 * Created by aruba on 2020/4/30.
 */
public class Tools {

    @Replace(clazz = "com.aruba.andfixapplication.Tools", method = "calc")
    public static int calc(int origin) {
        int result = origin / 1;
        return result;
    }

}
