package com.aruba.andfixapplication;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
        System.loadLibrary("art7");
    }

    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tv_result);
        DexManager.getInstance().setContext(this.getApplicationContext());
    }

    public void calc(View view) {
        tvResult.setText(Tools.calc(50)+"");
    }

    public void fix(View view) {
        DexManager.getInstance().loadDexFile(new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "out.dex"));
    }
}
