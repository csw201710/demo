package com.aruba.andfixapplication;

/**
 * Created by aruba on 2020/4/30.
 */
public class Tools {

    public static int calc(int origin) {
        int result = origin / 0;
        return result;
    }

}
