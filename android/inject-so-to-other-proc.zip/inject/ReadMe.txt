注入代码的格式:
./inject  com.me.keygen.activity  /data/local/tmp/injecttest/libhello.so

获取log输出
adb logcat -s INJECT

测试结果:
在android x86 18平台上测试失败





