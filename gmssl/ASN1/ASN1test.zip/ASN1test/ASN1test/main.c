
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#ifdef _DEBUG
#ifndef DBG_NEW
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#define new DBG_NEW
#endif
#endif  // _DEBUG

#include "Rectangle.h"
/*
	ʹ��asn1ve ͨ�� 1.asn1 �����ļ����Բ鿴 der����ľ�������
*/
static int write_out(const void *buffer, size_t size, void *app_key)
{
        FILE *out_fp = (FILE *)app_key;
        size_t wrote;
        wrote = fwrite(buffer, 1, size, out_fp);
        return (wrote == size)?0:-1;
}

static int write_der(
	const char* fileName,
	struct asn_TYPE_descriptor_s *type_descriptor,
	void *struct_ptr) {
	FILE *fp = fopen(fileName, "wb");
	asn_enc_rval_t ec;
	if (!fp)
	{
		perror("filename");
		exit(71);
	}
	ec = der_encode(type_descriptor, struct_ptr, write_out, fp);
	fclose(fp);

	if (ec.encoded == -1)
	{
		perror("Count not encode Rectangle.\n");
		exit(65);
	}
	else
	{
		printf("Created with BER encoded.\n");
	}
	return 0;
}


static void * read_der(const char* fileName,
	struct asn_TYPE_descriptor_s *type_descriptor) {
	char buf[40960] = { 0 };
	int bufLen = 0;
	void* struct_ptr = 0;

	FILE *fp = fopen(fileName, "rb");
	asn_dec_rval_t ec;
	if (!fp)
	{
		perror("filename");
		exit(-1);
	}
	bufLen = fread(buf, 1, sizeof(buf), fp);
	fclose(fp);

	printf("read data len: %d\n", bufLen);
	ec = ber_decode(0, type_descriptor, &struct_ptr, buf, bufLen);
	if (ec.code != RC_OK) {
		printf("ber_decode failed\n");
		exit(-1);
	}
	return struct_ptr;

}


int testRectangle() {
	Rectangle_t *rectangle;
	asn_enc_rval_t ec;

	rectangle = (Rectangle_t *)calloc(1, sizeof(Rectangle_t));
	if (!rectangle)
	{
		perror("calloc failed");
		exit(71);
	}

	rectangle->height = 42;
	rectangle->width = 23;

	write_der("Test", &asn_DEF_Rectangle, rectangle);

	xer_fprint(stdout, &asn_DEF_Rectangle, rectangle);

	SEQUENCE_free(&asn_DEF_Rectangle, rectangle, 0);
	return 0;
}

#include "Reporter.h"
int testReport() {
	int ret;
	Reporter_t reporter = {0};

	asn_long2INTEGER(&reporter.level, 10);
	

	ret = OCTET_STRING_fromString(&reporter.person.name, "this is name");
	if (ret != 0) {
		printf("OCTET_STRING_fromString failed!\n");
		return -1;
	}

	reporter.person.age = 160;

	ret = OCTET_STRING_fromString(&reporter.comment, "this is comment");
	if (ret != 0) {
		printf("OCTET_STRING_fromString failed!\n");
		return -1;
	}

	//���Լ��
	char errbuf[128]; /* Buffer for error message */
	size_t errlen = sizeof(errbuf); /* Size of the buffer */
	ret = asn_check_constraints(&asn_DEF_Reporter, &reporter, errbuf, &errlen);
	/* assert(errlen < sizeof(errbuf)); // you may rely on that */
	if (ret) {
		fprintf(stderr, "Constraint validation failed : %s\n",
			errbuf /* errbuf is properly nul-terminated */
		);
		return -1;
	}

	write_der("Test", &asn_DEF_Reporter, &reporter);
	xer_fprint(stdout, &asn_DEF_Reporter, &reporter);
	SEQUENCE_free(&asn_DEF_Reporter, &reporter, 1);
	return 0;
}

int testReadReporter() {
	Reporter_t *reporter = 0;

	reporter = (Reporter_t *)read_der("Test", &asn_DEF_Reporter);
	xer_fprint(stdout, &asn_DEF_Reporter, reporter);

	SEQUENCE_free(&asn_DEF_Reporter, reporter, 0);
	return 0;
}
#include "TimeStampReq.h"

typedef struct {
	int version;
	unsigned char hashedMessage[128];
	int hashedMessageLen;
	unsigned char nonce[128];
	int nonceLen;
	int certReq;
} time_stamp_req;

typedef struct {
	int a;
} time_stamp_resp;

static TimeStampReq_t*	construct_time_stamp_req(time_stamp_req* req) {
	int ret;

	const int alg_oid[] = { 1, 2, 156 ,10197, 1 ,401 };
	int hash_buf[128];
	int hash_buf_len = sizeof(hash_buf);
	TimeStampReq_t* timeReq = 0;

	timeReq = (TimeStampReq_t*) calloc(1, sizeof(TimeStampReq_t));
	assert(timeReq != 0);

	asn_long2INTEGER(&timeReq->version, req->version);

	ret = OBJECT_IDENTIFIER_set_arcs(&timeReq->messageImprint.hashAlgorithm.algorithm,
		alg_oid, sizeof(alg_oid[0]), sizeof(alg_oid) / sizeof(alg_oid[0]));
	assert(ret == 0);

	hash_buf_len = 32;
	ret = OCTET_STRING_fromBuf(&timeReq->messageImprint.hashedMessage, req->hashedMessage, req->hashedMessageLen);
	assert(ret == 0);

	//asn_ulong2INTEGER(timeReq.nonce, 17811273552548890879);
	
	timeReq->nonce = (INTEGER_t*)malloc( sizeof(INTEGER_t));
	assert(timeReq->nonce != 0);

	

	timeReq->nonce->buf = malloc(req->nonceLen + 1);
	assert(timeReq->nonce->buf != 0);

	memcpy(timeReq->nonce->buf, req->nonce, req->nonceLen);
	timeReq->nonce->size = req->nonceLen;

	timeReq->certReq = (INTEGER_t*)malloc(sizeof(BOOLEAN_t));
	(*timeReq->certReq) = req->certReq;

	write_der("Test2", &asn_DEF_TimeStampReq, timeReq);
	xer_fprint(stdout, &asn_DEF_TimeStampReq, timeReq);


	//any
	//ANY_new_fromType
	//ANY_to_type

	//asn_set_add()

	return timeReq;
}
static void free_timestamp_req_t(TimeStampReq_t* req) {
	assert(req != 0);
	SEQUENCE_free(&asn_DEF_TimeStampReq, req, 0);
}


static int	construct_time_stamp_resp(time_stamp_resp* req) {
	
	return 0;
}

void testTimeStampReq() {
	int ret;
	time_stamp_req req;
	req.version = 1;
	req.hashedMessageLen = 32;
	req.nonceLen = 32;
	TimeStampReq_t * rq = construct_time_stamp_req(&req);
	free_timestamp_req_t(rq);

}

int main(int ac, char **av)
{
	//_CrtDumpMemoryLeaks();
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	//testRectangle();
	//testReport();
	//testReadReporter();
	testTimeStampReq();
	
}
