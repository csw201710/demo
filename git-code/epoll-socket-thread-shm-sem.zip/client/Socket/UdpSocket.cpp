#include "UdpSocket.h"

CUdpSocket::CUdpSocket(void)
{
}

CUdpSocket::~CUdpSocket(void)
{
}

