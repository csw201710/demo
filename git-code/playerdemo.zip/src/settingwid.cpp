#include "settingwid.h"

SettingWid::SettingWid(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}

SettingWid::~SettingWid()
{
}
