#pragma once
#include "TagType.h"

class CTagAudio: public CTagType
{
public:
	CTagAudio();
	~CTagAudio();

	// ��ʾ;
	virtual void Display();
};

