//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CPPTooltip_demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CPPTOOTYPE                  129
#define IDD_DEMO_DIALOG                 130
#define IDD_PPTOOLTIP_OPTIONS           131
#define IDD_PAGE_COLORS                 132
#define IDD_PAGE_BEHAVIOUR              134
#define IDD_PAGE_SIZES                  135
#define IDD_PAGE_STYLES                 136
#define IDD_PAGE_CSS_STYLES             137
#define IDB_CODEPROJECT                 138
#define IDI_ICON_ATTENTION              139
#define IDI_ICON_STOP                   140
#define IDI_ICON_QUESTION               141
#define IDI_ICON_INFORMATION            142
#define IDD_PAGETEST_GENERAL            143
#define IDD_PAGETEST_HYPERLINKS         145
#define IDI_MAIL_ME                     146
#define IDD_PAGETEST_IMAGES             147
#define IDB_SMILES                      148
#define IDD_PAGETEST_TABLE              149
#define IDD_PAGETEST_LIST_TREE          150
#define IDD_PAGETEST_MISC               151
#define IDB_MAP                         154
#define IDD_PAGE_SHADOW                 155
#define IDI_BLANK_BLACK                 157
#define IDI_CLOSE_APP                   158
#define IDB_GLOBE                       159
#define IDC_LOOK_TOOLTIP                1000
#define IDC_DISABLE_LOOK_BTN            1001
#define IDC_TOOLTIP_STRING              1002
#define IDC_STATIC1                     1003
#define IDC_STATIC3                     1004
#define IDC_COMBO1                      1005
#define IDC_COMBO2                      1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008
#define IDC_BUTTON3                     1009
#define IDC_EDIT1                       1010
#define IDC_BUTTON5                     1010
#define IDC_CHECK1                      1011
#define IDC_EDIT3                       1011
#define IDC_BUTTON6                     1011
#define IDC_CHECK2                      1012
#define IDC_EDIT4                       1012
#define IDC_BUTTON4                     1012
#define IDC_CHECK3                      1013
#define IDC_EDIT5                       1013
#define IDC_BUTTON7                     1013
#define IDC_CHECK4                      1014
#define IDC_EDIT6                       1014
#define IDC_CHECK5                      1015
#define IDC_EDIT7                       1015
#define IDC_EDIT2                       1016
#define IDC_EDIT8                       1016
#define IDC_RADIO1                      1016
#define IDC_EDIT9                       1017
#define IDC_RADIO2                      1017
#define IDC_EDIT10                      1018
#define IDC_RADIO3                      1018
#define IDC_EDIT11                      1019
#define IDC_RADIO4                      1019
#define IDC_CHECK6                      1019
#define IDC_EDIT12                      1020
#define IDC_RADIO5                      1020
#define IDC_RADIO6                      1021
#define IDC_DEBUG_MODE                  1021
#define IDC_EDIT13                      1021
#define IDC_RADIO7                      1022
#define IDC_STATIC2                     1022
#define IDC_RADIO8                      1023
#define IDC_LIST1                       1023
#define IDC_RADIO9                      1024
#define IDC_LIST2                       1024
#define IDC_RADIO10                     1025
#define IDC_TREE1                       1025
#define IDC_RADIO11                     1026
#define IDC_RADIO12                     1027
#define ID_DEMO_DIALOG                  32771
#define ID_TOP_MENUTIP                  32773
#define ID_VCENTER_MENUTIP              32774
#define ID_BOTTOM_MENUTIP               32775
#define ID_LEFT_MENUTIP                 32776
#define ID_CENTER_MENUTIP               32777
#define ID_RIGHT_MENUTIP                32778
#define ID_ANCHOR_RIGHTEDGE_TOP         32781
#define ID_ANCHOR_RIGHTEDGE_VCENTER     32782
#define ID_ANCHOR_RIGHTEDGE_BOTTOM      32783
#define ID_ANCHOR_BOTTOMEDGE_LEFT       32784
#define ID_ANCHOR_BOTTOMEDGE_CENTER     32785
#define ID_ANCHOR_BOTTOMEDGE_RIGHT      32786
#define ID_ANCHOR_TOPEDGE_LEFT          32787
#define ID_ANCHOR_TOPEDGE_CENTER        32788
#define ID_ANCHOR_TOPEDGE_RIGHT         32789
#define ID_ANCHOR_LEFTEDGE_TOP          32790
#define ID_ANCHOR_LEFTEDGE_VCENTER      32791
#define ID_ANCHOR_LEFTEDGE_BOTTOM       32792
#define ID_TOOLTIP_BALLOON              32793

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
