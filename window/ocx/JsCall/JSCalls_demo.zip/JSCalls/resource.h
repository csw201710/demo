//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by JSCall.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORM_LEFT_VIEW              101
#define CG_IDD_NAVIGATEBAR              102
#define CG_ID_VIEW_NAVIGATEBAR          103
#define IDR_MAINFRAME                   128
#define IDR_JSCALLTYPE                  129
#define IDD_DIALOG_CALL_JSCRIPT         131
#define IDC_TREE_CTRL                   1000
#define IDC_EDIT_URL                    1001
#define IDC_EDIT_FUNCTION_NAME          1002
#define IDC_EDIT_ARGUMENTS              1003
#define IDC_BUTTON_RUN                  1004
#define ID_IE_GO_BACK                   32772
#define ID_IE_GO_FORWARD                32775
#define ID_CALL_JSCRIPT                 32776
#define ID_IE_STOP                      32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
