#include "stdafx.h"
#include "IOCPBase.h"
#include <mstcpip.h>

#pragma comment(lib, "WS2_32.lib")

IOContextPool SocketContext::m_ioContextPool;		// ��ʼ��

IOCPBase::IOCPBase() :
	m_completionPort(INVALID_HANDLE_VALUE),
	m_workerThreads(NULL),
	m_workerThreadNum(0),
	m_IP(L"127.0.0.1"),
	m_port(10240),
	m_listenSockContext(NULL),
	m_fnAcceptEx(NULL),
	m_fnGetAcceptExSockAddrs(NULL),
	m_connectCnt(0),
	m_acceptPostCnt(0)
{
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);
	m_stopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
}


IOCPBase::~IOCPBase()
{
	RELEASE_HANDLE(m_stopEvent);
	Stop(); 
	WSACleanup();
}


BOOL IOCPBase::Start(int port, int maxConn, int maxIOContextInPool, int maxSocketContextInPool)
{
	if (false == InitializeIOCP())
		return false;

	if (false == InitializeListenSocket())
	{
		DeInitialize();
		return false;
	}

	return true;
}

void IOCPBase::Stop()
{
	if (m_listenSockContext != NULL && m_listenSockContext->m_connSocket != INVALID_SOCKET)
	{
		// ����ر��¼�
		SetEvent(m_stopEvent);

		for (int i = 0; i < m_workerThreadNum; i++)
		{
			// ֪ͨ������ɶ˿��˳�
			PostQueuedCompletionStatus(m_completionPort, 0, (DWORD)EXIT_CODE, NULL);
		}

		// �ȴ����й����߳��˳�
		WaitForMultipleObjects(m_workerThreadNum, m_workerThreads, TRUE, INFINITE);

		// �ͷ�������Դ
		DeInitialize();
	}
}

BOOL IOCPBase::SendData(SocketContext * socketContext, char * data, int size)
{
	IOContext* ioContext = socketContext->GetNewIOContext();
	ioContext->Reset();
	
	memcpy(ioContext->m_wsaBuf.buf, data, size);
	ioContext->m_wsaBuf.len = size;
	
	ioContext->m_ioSocket = socketContext->m_connSocket; //�����һ�������ͷ����ε����⡣

	PostSend(socketContext, ioContext);
	return 0;
}

wstring IOCPBase::GetLocalIP()
{
	//char hostName[MAX_PATH] = { 0 };
	//gethostname(hostName, MAX_PATH);
	//struct hostent FAR *hostent = gethostbyname(hostName);
	//if (hostent == NULL)
	//{
	//	return string(DEFAULT_IP);
	//}

	//// ȡ��m_IP��ַ�б��еĵ�һ��Ϊ���ص�m_IP(��Ϊһ̨�������ܻ�󶨶��m_IP)
	//char *addr = hostent->h_addr_list[0];
	//in_addr inAddr;
	//memmove(&inAddr, addr, 4);

	//return string(inet_ntoa(inAddr));
	return wstring(DEFAULT_IP);
}

BOOL IOCPBase::InitializeIOCP()
{
	m_completionPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
	if (NULL == m_completionPort)
	{
		return false;
	}

	m_workerThreadNum = WORKER_THREADS_PER_PROCESSOR * GetNumOfProcessors();
	m_workerThreads = new HANDLE[m_workerThreadNum];

	for (int i = 0; i < m_workerThreadNum; i++)
	{
		m_workerThreads[i] = CreateThread(0, 0, WorkerThreadProc, (void *)this, 0, 0);
	}
	return true;
}

BOOL IOCPBase::InitializeListenSocket()
{
	// �������ڼ�����socket��Context
	m_listenSockContext = new SocketContext;
	m_listenSockContext->m_connSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	if (INVALID_SOCKET == m_listenSockContext->m_connSocket)
		return false;

	// ��socket�󶨵���ɶ˿���
	if (NULL == CreateIoCompletionPort((HANDLE)m_listenSockContext->m_connSocket, m_completionPort, (DWORD)m_listenSockContext, 0))
	{
		RELEASE_SOCKET(m_listenSockContext->m_connSocket);
		return false;
	}

	//��������ַ��Ϣ�����ڰ�socket
	sockaddr_in serverAddr;

	// ����ַ��Ϣ
	ZeroMemory((char *)&serverAddr, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddr.sin_port = htons(m_port);

	// �󶨵�ַ�Ͷ˿�
	if (SOCKET_ERROR == bind(m_listenSockContext->m_connSocket, (sockaddr *)&serverAddr, sizeof(serverAddr)))
	{
		return false;
	}

	// ��ʼ����
	if (SOCKET_ERROR == listen(m_listenSockContext->m_connSocket, SOMAXCONN))
	{
		return false;
	}

	GUID guidAcceptEx = WSAID_ACCEPTEX;
	GUID guidGetAcceptSockAddrs = WSAID_GETACCEPTEXSOCKADDRS;
	// ��ȡ��չ����ָ��
	DWORD dwBytes = 0;
	if (SOCKET_ERROR == WSAIoctl(
		m_listenSockContext->m_connSocket,
		SIO_GET_EXTENSION_FUNCTION_POINTER,
		&guidAcceptEx,
		sizeof(guidAcceptEx),
		&m_fnAcceptEx,
		sizeof(m_fnAcceptEx),
		&dwBytes,
		NULL,
		NULL))
	{
		DeInitialize();
		return false;
	}

	if (SOCKET_ERROR == WSAIoctl(
		m_listenSockContext->m_connSocket,
		SIO_GET_EXTENSION_FUNCTION_POINTER,
		&guidGetAcceptSockAddrs,
		sizeof(guidGetAcceptSockAddrs),
		&m_fnGetAcceptExSockAddrs,
		sizeof(m_fnGetAcceptExSockAddrs),
		&dwBytes,
		NULL,
		NULL))
	{
		DeInitialize();
		return false;
	}

	for (size_t i = 0; i < MAX_POST_ACCEPT; i++)
	{
		IOContext *ioContext = m_listenSockContext->GetNewIOContext();
		if (false == PostAccept(m_listenSockContext, ioContext))
		{
			m_listenSockContext->RemoveContext(ioContext);
			return false;
		}
	}
	return true;
}

void IOCPBase::DeInitialize()
{
	// �ر�ϵͳ�˳��¼����
	RELEASE_HANDLE(m_stopEvent);

	// �ͷŹ������߳̾��ָ��
	for (int i = 0; i<m_workerThreadNum; i++)
	{
		RELEASE_HANDLE(m_workerThreads[i]);
	}

	RELEASE(m_workerThreads);

	// �ر�IOCP���
	RELEASE_HANDLE(m_completionPort);

	// �رռ���Socket
	RELEASE(m_listenSockContext);
}

BOOL IOCPBase::IsSocketAlive(SOCKET sock)
{
	int nByteSent = send(sock, "", 0, 0);
	if (-1 == nByteSent) 
		return false;
	return true;
}

int IOCPBase::GetNumOfProcessors()
{
	SYSTEM_INFO si;
	GetSystemInfo(&si);
	return si.dwNumberOfProcessors;
}

BOOL IOCPBase::AssociateWithIOCP(SocketContext * sockContext)
{
	// �����ںͿͻ���ͨ�ŵ�SOCKET�󶨵���ɶ˿���
	HANDLE hTemp = CreateIoCompletionPort((HANDLE)sockContext->m_connSocket, m_completionPort, (DWORD)sockContext, 0);

	if (NULL == hTemp)
	{
		return false;
	}

	return true;
}

BOOL IOCPBase::PostAccept(SocketContext * sockContext, IOContext * ioContext)
{
	DWORD dwBytes = 0;
	ioContext->m_ioType = ACCEPT_POSTED;
	ioContext->m_ioSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	if (INVALID_SOCKET == ioContext->m_ioSocket)
	{
		return false;
	}
	
	// �����ջ�����Ϊ0,��AcceptExֱ�ӷ���,��ֹ�ܾ����񹥻�
	if (false == m_fnAcceptEx(m_listenSockContext->m_connSocket, ioContext->m_ioSocket, ioContext->m_wsaBuf.buf,
		0, sizeof(sockaddr_in) + 16, sizeof(sockaddr_in) + 16, &dwBytes, &ioContext->m_overLapped))
	{
		if (WSA_IO_PENDING != WSAGetLastError())
		{
			return false;
		}
	}

	InterlockedIncrement(&m_acceptPostCnt);
	return true;
}

BOOL IOCPBase::PostRecv(SocketContext * sockContext, IOContext *ioContext)
{
	DWORD dwFlags = 0, dwBytes = 0;
	ioContext->Reset();
	ioContext->m_ioType = RECV_POSTED;

	int nBytesRecv = WSARecv(ioContext->m_ioSocket, &ioContext->m_wsaBuf, 1, &dwBytes, &dwFlags, &ioContext->m_overLapped, NULL);
	// �������ֵ���󣬲��Ҵ���Ĵ��벢����Pending�Ļ����Ǿ�˵������ص�����ʧ����
	DWORD errRet = WSAGetLastError();
	if ((SOCKET_ERROR == nBytesRecv) && (WSA_IO_PENDING != errRet))
	{
		DoClose(sockContext);
		return false;
	}
	return true;
}

BOOL IOCPBase::PostSend(SocketContext * sockContext, IOContext *ioContext)
{
	ioContext->m_ioType = SEND_POSTED;
	DWORD dwBytes = 0, dwFlags = 0;

	if (::WSASend(ioContext->m_ioSocket, &ioContext->m_wsaBuf, 1, &dwBytes, dwFlags, &ioContext->m_overLapped, NULL) != NO_ERROR)
	{
		DWORD ret = WSAGetLastError();
		if (ret != WSA_IO_PENDING)
		{
			//DoClose(sockContext);
			return false;
		}
	}
	return true;
}

BOOL IOCPBase::DoAccpet(SocketContext * sockContext, IOContext * ioContext)
{
	
	InterlockedIncrement(&m_connectCnt);
	InterlockedDecrement(&m_acceptPostCnt);
	SOCKADDR_IN *clientAddr = NULL;
	SOCKADDR_IN *localAddr = NULL;
	int clientAddrLen, localAddrLen;
	clientAddrLen = localAddrLen = sizeof(SOCKADDR_IN);

	// 1. ��ȡ��ַ��Ϣ ��GetAcceptExSockAddrs�����������Ի�ȡ��ַ��Ϣ��������˳��ȡ����һ�����ݣ�
	m_fnGetAcceptExSockAddrs(ioContext->m_wsaBuf.buf, 0, localAddrLen, clientAddrLen, (LPSOCKADDR *)&localAddr, &localAddrLen, (LPSOCKADDR *)&clientAddr, &clientAddrLen);

	// 2. Ϊ�����ӽ���һ��SocketContext 
	SocketContext *newSockContext = new SocketContext;
	newSockContext->m_connSocket = ioContext->m_ioSocket;
	memcpy_s(&(newSockContext->m_clientAddr), sizeof(SOCKADDR_IN), clientAddr, sizeof(SOCKADDR_IN));

	// 3. ��listenSocketContext��IOContext ���ú����Ͷ��AcceptEx
	ioContext->Reset();
	if (false == PostAccept(m_listenSockContext, ioContext))
	{
		m_listenSockContext->RemoveContext(ioContext);
	}

	// 4. ����socket����ɶ˿ڰ�
	if (NULL == CreateIoCompletionPort((HANDLE)newSockContext->m_connSocket, m_completionPort, (DWORD)newSockContext, 0))
	{
		DWORD dwErr = WSAGetLastError();
		if (dwErr != ERROR_INVALID_PARAMETER)
		{
			DoClose(newSockContext);
			return false;
		}
	}

	// ������tcp_keepalive
	tcp_keepalive alive_in;
	tcp_keepalive alive_out;
	alive_in.onoff = TRUE;
	alive_in.keepalivetime = 1000 * 60;  // 60s  �೤ʱ�䣨 ms ��û�����ݾͿ�ʼ send ������
	alive_in.keepaliveinterval = 1000 * 10; //10s  ÿ���೤ʱ�䣨 ms �� send һ��������
	unsigned long ulBytesReturn = 0;
	if (SOCKET_ERROR == WSAIoctl(newSockContext->m_connSocket, SIO_KEEPALIVE_VALS, &alive_in, sizeof(alive_in), &alive_out, sizeof(alive_out), &ulBytesReturn, NULL, NULL))
	{
		TRACE(L"WSAIoctl failed: %d/n", WSAGetLastError());
	}


	OnConnectionEstablished(newSockContext);

	// 5. ����recv���������ioContext���������ӵ�socket��Ͷ��recv����
	IOContext *newIoContext = newSockContext->GetNewIOContext();
	newIoContext->m_ioType = RECV_POSTED;
	newIoContext->m_ioSocket = newSockContext->m_connSocket;
	// Ͷ��recv����
	if (false == PostRecv(newSockContext, newIoContext))
	{
		DoClose(sockContext);
		return false;
	}

	return true;
}

BOOL IOCPBase::DoRecv(SocketContext * sockContext, IOContext * ioContext)
{
	OnRecvCompleted(sockContext, ioContext);
	ioContext->Reset();
	if (false == PostRecv(sockContext, ioContext))
	{
		DoClose(sockContext);
		return false;
	}
	return true;
}

BOOL IOCPBase::DoSend(SocketContext * sockContext, IOContext * ioContext)
{
	OnSendCompleted(sockContext, ioContext);
	return 0;
}

BOOL IOCPBase::DoClose(SocketContext * sockContext)
{
	InterlockedDecrement(&m_connectCnt);
	RELEASE(sockContext);
	return true;
}

DWORD IOCPBase::WorkerThreadProc(LPVOID lpParam)
{
	IOCPBase *iocp = (IOCPBase*)lpParam;
	OVERLAPPED *ol = NULL;
	SocketContext *sockContext;
	DWORD dwBytes = 0;
	IOContext *ioContext = NULL;

	while (WAIT_OBJECT_0 != WaitForSingleObject(iocp->m_stopEvent, 0))
	{
		BOOL bRet = GetQueuedCompletionStatus(iocp->m_completionPort, &dwBytes, (PULONG_PTR)&sockContext, &ol, INFINITE);

		// ��ȡ����Ĳ���
		ioContext = CONTAINING_RECORD(ol, IOContext, m_overLapped);

		// �յ��˳���־
		if (EXIT_CODE == (DWORD)sockContext)
		{
			break;
		}

		if (!bRet)
		{
			DWORD dwErr = GetLastError();

			// ����ǳ�ʱ�ˣ����ټ����Ȱ�  
			if (WAIT_TIMEOUT == dwErr)
			{
				// ȷ�Ͽͻ����Ƿ񻹻���...
				if (!iocp->IsSocketAlive(sockContext->m_connSocket))
				{
					iocp->OnConnectionClosed(sockContext);

					// ����socket
					iocp->DoClose(sockContext);
					continue;
				}
				else
				{
					continue;
				}
			}
			// �����ǿͻ����쳣�˳���(64)
			else if (ERROR_NETNAME_DELETED == dwErr)
			{
				iocp->OnConnectionError(sockContext, dwErr);

				// ����socket
				iocp->DoClose(sockContext);
				continue;
			}
			else
			{
				iocp->OnConnectionError(sockContext, dwErr);

				// ����socket
				iocp->DoClose(sockContext);
				continue;
			}
		}
		else
		{
			// �ж��Ƿ��пͻ��˶Ͽ�
			if ((0 == dwBytes) && (RECV_POSTED == ioContext->m_ioType || SEND_POSTED == ioContext->m_ioType))
			{
				iocp->OnConnectionClosed(sockContext);

				// ����socket
				iocp->DoClose(sockContext);
				continue;
			}
			else
			{
				switch (ioContext->m_ioType)
				{
				case ACCEPT_POSTED:
					iocp->DoAccpet(sockContext, ioContext);
					break;
				case RECV_POSTED:
					iocp->DoRecv(sockContext, ioContext);
					break;
				case SEND_POSTED:
					iocp->DoSend(sockContext, ioContext);
					break;
				default:
					break;
				}
			}
		}
	}

	// �ͷ��̲߳���
	RELEASE(lpParam);
	return 0;
}
