#include <stdio.h>
#include "uWS/uWS.h"
#include <iostream>
#pragma comment(lib,"ws2_32.lib")
using namespace std;


int main(int argc, char *argv[])
{
	uWS::Hub h;
	//���յ�������
	h.onMessage([](uWS::WebSocket<uWS::CLIENT> *ws, char *message, size_t length, uWS::OpCode opCode) {
		char buf[100] = { 0 };
		memcpy(buf, message, length);

		std::cout << "from server: " << std::string(message, length) << std::endl;
		std::string res = std::to_string(atoi(buf) + 1);
		ws->send(res.data(), res.length(), opCode);
	});
	h.connect("ws://localhost:3000", nullptr);
	h.run();
	return 0;
}
