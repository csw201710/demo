#!/bin/bash

dpkg -b deb mysoftware-0.0.2.deb



	
