#ifndef __LOG__H__
#define __LOG__H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ERROR(...) \
do{ \
    fprintf(stderr, "\33[01;31m[ERROR ]\33[0m%s %s(Line %d): ",__FILE__,__FUNCTION__,__LINE__); \
    fprintf(stderr, __VA_ARGS__); \
    printf("\n"); \
}while(0) ;

#define INFO(...) \
do{ \
    fprintf(stdout, "\33[34m[INFO  ]\33[0m%s %s(Line %d): ",__FILE__,__FUNCTION__,__LINE__); \
    fprintf(stdout, __VA_ARGS__); \
    printf("\n"); \
}while(0) ;




#endif //__LOG__H__