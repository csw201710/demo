#include <stdio.h>
#include "Log.h"

int main(int argc, char* argv[])
{
	INFO("this is info");
	ERROR("this is error");
	return 0;
}


