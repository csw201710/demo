char zip_ispasswd(const char* fn, const char* pwd);
char rar_ispasswd(const char *fn, const char *pwd);
void rar_init(const char *fn);
void zip_init(const char *fn);
