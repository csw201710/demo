#include <stdlib.h>

#include "unzip.h"
#include "unrarlib.h"

char* filename;
unzFile uf;

void zip_init(const char *fn)
{
    uf = unzOpen(fn);
}

char zip_ispasswd(const char *fn, const char *pwd)
{
    unzOpenCurrentFilePassword(uf, pwd);
    void* buf = malloc(1000);
    return unzReadCurrentFile(uf, buf, 1000) == 1000;
}

void rar_init(const char *fn)
{
    ArchiveList_struct *List = NULL;
    urarlib_list(fn, (ArchiveList_struct*)&List);
    filename = List->item.Name;
    urarlib_freelist(List);
}

char rar_ispasswd(const char *fn, const char *pwd)
{
    char *dataptr;
    unsigned long datasize;
    return urarlib_get(&dataptr, &datasize, filename, fn, pwd);
}

