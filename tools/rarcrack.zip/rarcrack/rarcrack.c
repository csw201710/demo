/*
 *   Copyright (C) 2007 by David Zoltan Kedves
 *   kedazo@gmail.com
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "arch/test.h"

#define PWD_LEN 100
#define SLEEPTIME 1

char *ABC = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
int ABCLEN;

char password[PWD_LEN+1] = {0};
char *ptrpassword[PWD_LEN+1] = {0};

char filename[255] = {0};

int finished = 0;
int dico = 0; /* -1 ascii, 0 normal, 1 dict */

int PWMin = 1;
int PWMax = PWD_LEN;
long counter = 0;

char** wlist;

char (*pwdtestfunc)(const char* fn, const char* pwd);

void save_state(void)
{
    printf("Saving actual state.\n");
    FILE* f = fopen(".rarcrackerst", "w");
    fprintf(f, "%s", password);
    fclose(f);
}

void load_state()
{
    FILE* f = NULL;
    f = fopen(".rarcrackerst", "r");
    if (f == NULL) {
        printf("State doesn't exist.\n");
        return;
    }
    fscanf(f, "%s", password);
    if (dico == 0)
    {
        int i, j;
        for (i = 0; i < strlen(password); i++)
        {
            if (password[i] == 0)
                ptrpassword[i] = 0;
            else
                for (j = 0; j < ABCLEN; j++)
                    if (password[i] == ABC[j])
                        ptrpassword[i] = &ABC[j];
        }
    }
}


int filedetect(const char* fn)
{
    const int numtypes = 3;
    const char* HEAD[] = {"Rar!", "7z", "PK"};
    FILE* f = NULL;
    f = fopen(fn, "r");
    if (f == NULL) {
        printf("File doesn't exist !\n");
        return -1;
    }
    char head[5];
    fread(head, 1, 4, f);
    int t;
    int i, j;
    for (i = 0; i < numtypes; i++)
    {
        t = 0;
        for (j = 0; j < strlen(HEAD[i]); j++)
            if (HEAD[i][j] != head[j])
                t = -1;
        if (t == 0) {
            printf("File type %d\n", i);
            return i;
        }
    }
    return -1;
}

int file_push(char* dicofilename)
{
    FILE *p = NULL;
    p = fopen(dicofilename, "r");
    if (p == NULL)
        return 1;
    int c;
    int nbl = 0;
    while ((c = fgetc(p)) != EOF)
        if (c == '\n') nbl++;

    wlist = (char**)malloc(nbl*sizeof(char**));
    rewind(p);
    for (; c > 0; c--)
    {
        wlist[c] = (char*)malloc(PWD_LEN*sizeof(char));
        fscanf(p, "%s", wlist[c]);
    }

    fclose(p);

    strcpy(password, *wlist++);
    return 0;
}

void abcptrtostr(char* str, char** ptrl)
{
    int i;
    for (i = 0; i < PWD_LEN-1; i++)
        str[i] = (ptrpassword[i] == 0) ? 0 : *ptrpassword[i];
}

char* nextpass()
{
    int i;
    ++ptrpassword[0];
    for (i = 0; i < strlen(password) && password[i] != 0; i++)
    {
        if (ptrpassword[i] >= &ABC[ABCLEN])
        {
            ptrpassword[i] = &ABC[0];
            if (ptrpassword[i+1] == 0)
                ptrpassword[i+1] = &ABC[0];
            else
                ptrpassword[i+1]++;
        }
    }

    abcptrtostr(password, ptrpassword);
    return password;
}

char* np_dict()
{
    if (!strcpy(password, *wlist++))
        finished = 1;
    return password;
}

char* np_ascii()
{
    int i;
    for (i = strlen(password)-1; i > 0; i--)
    {
        if (password[i] == 'z')
        {
            password[i] = '0';
            if (i > 0) password[i-1]++;
        }
        else if (password[i] == '9')
            password[i] = 'A';
        else if (password[i] == 'Z')
            password[i] = 'a';
        else
            password[i]++;
    }
    return password;
}

void status_thread()
{
    int pwds;
    for (;;)
    {
        sleep(SLEEPTIME);
        pwds = counter / SLEEPTIME;
        counter = 0;
        if (finished)
            break;
        printf("Probing: '%s' [%d pwds/sec]\n", password, pwds);
    }
}

void crack_thread()
{
    char *current;

    for (;;)
    {
        if (dico == 0)
            current = nextpass();
        else if (dico == -1)
            current = np_ascii();
        else
            current = np_dict();

        if (pwdtestfunc(filename, current))
        {
            finished = 1;
            printf("GOOD: password cracked: '%s'\n", current);
            break;
        }
        counter++;
        if (finished)
            break;
    }
}

void crack_start(int threads)
{
    pthread_t th[31];
    int i;
    for (i = 0; i < threads; i++) {
        pthread_create(&th[i], NULL, (void*)&crack_thread, NULL);
    }
    pthread_create(&th[30], NULL, (void*)&status_thread, NULL);
    for (i = 0; i < threads; i++) {
        pthread_join(th[i], NULL);
    }
    pthread_join(th[30], NULL);
    return;
}

int main(int argc, char *argv[])
{
    int i;
    int threads = 5;
    int archive_type = -1;
    char* chaine;
    char ABC_Num[] = "0123456789";
    char ABC_LC[] = "abcdefghijklmnopqrstuvwxyz";
    char ABC_UC[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char ABC_SC[] = "*.,_- ";

    printf("RarCrack! Open-Source\n");
    printf("Add of an awful dict & ASCII test by students Universite Paris 12\n");
    printf("A *lot* ameliorated by a stupid 14 old hacker\n\n");

    ABCLEN = strlen(ABC);

    for (i = 1; i < argc; i++)
    {
        if (argv[i][0] == '-' && argv[i][1] == '-')
        {
            if (strcmp(argv[i], "--help") == 0)
            {
                printf("Usage:   rarcrack archive [--help] [--threads NUM] [--dict FILE] [--PWL MIN MAX] [--string 0Aa*] [--ascii]\n\n");
                printf("Options: --help: show this screen.\n");
                printf("         --threads: you can specify how many threads\n");
                printf("                    will be ran, maximum 30 (default: 5)\n\n");
                printf("         --PWL:     you can specify the long of the password\n");
                printf("                    will be used beteewen min and max \n\n");
                printf("Algorithms:\n");
                printf("         --dict:    you can specify the dictionary file to use\n");
                printf("                    dictionary mode will be used\n\n");
                printf("         --string:  you can specify the type of characters that will be used\n");
                printf("                    0 for Numerical ABC, \n");
                printf("                    a for LowerCase, \n");
                printf("                    A for UpperCase, \n");
                printf("                    * for special character : '*', '-', '_', ' ', '.', ',', \n");
                printf("         --ascii: use ascii code for crack\n");
                printf("                    only alpha numeric char\n");
                return 0;
            }
            else if (strcmp(argv[i], "--threads") == 0)
            {
                if ((i + 1) < argc)
                {
                    sscanf(argv[++i], "%d", &threads);
                    if (threads < 1) threads = 5;
                    if (threads > 30) {
                        printf("INFO: Number of threads adjusted to 30\n");
                        threads = 30;
                    }
                }
                else {
                    printf("ERROR: Missing parameter for option: --threads!\n");
                    return 1;
                }
            }
            else if (strcmp(argv[i],"--dict") == 0)
            {
                if ((i + 1) < argc)
                {
                    dico = 1;
                    file_push(argv[++i]);
                }
                else {
                    printf("ERROR: Missing parameter for option: --dict!\n");
                    return 1;
                }
            }
            else if (strcmp(argv[i],"--PWL") == 0)
            {
                if ((i + 2) < argc) {
                    PWMin = atoi(argv[++i]);
                    PWMax = atoi(argv[++i]);
                }
                else {
                    printf("ERROR: Missing parameter for option: --PWL!\n");
                    return 1;
                }
            }
            else if (strcmp(argv[i],"--string") == 0)
            {
                if ((i + 1) < argc) {
                    chaine = (char*) argv[++i];

                    ABC = (char*)malloc((PWD_LEN+1)*sizeof(char));
                    if (strchr(chaine,'0')!=NULL)
                        strcat(ABC,ABC_Num);
                    if (strchr(chaine,'a')!=NULL)
                        strcat(ABC,ABC_LC);
                    if (strchr(chaine,'A')!=NULL)
                        strcat(ABC,ABC_UC);
                    if (strchr(chaine,'*')!=NULL)
                        strcat(ABC,ABC_SC);
                }
                else {
                    printf("ERROR: Missing parameter for option: --string !\n");
                    return 1;
                }
            }
            else if(strcmp(argv[i], "--ascii") == 0)
                dico = -1;
        }
        else
            strcpy(filename, argv[i]);
    }

    if (filename[0] == 0)
    {
        printf("USAGE: rarcrack archive [options]\n");
        printf("       For more information please run \"rarcrack --help\"\n");
        return 1;
    }

    archive_type = filedetect(filename);

    if (archive_type == -1) {
        printf("ERROR: Couldn't detect archive type\n");
        return 1;
    }

    ptrpassword[0] = &ABC[0];
    for (i = 0; i < PWMin; i++)
        password[i] = ABC[0];
        ptrpassword[i] = &ABC[0];
 
    switch (archive_type)
    {
        case 0:
            pwdtestfunc = &rar_ispasswd;
            rar_init(filename);
            break;
        case 2:
            pwdtestfunc = &zip_ispasswd;
            zip_init(filename);
            break;
    }

    load_state();
    atexit(save_state);
    crack_start(threads);
    return 0;
}


