#include "add.h"
#include <stdio.h>

int main(int argc, char** argv)
{
    printf("add(1, 2) = %d\n", add(1, 2));
    return 0;
}
