#include "mainwindow.h"
#include "sessionbasewindow.h"
#include "timewidget.h"
#include <QLabel>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    m_mainLayou = new QVBoxLayout;
    SessionBaseWindow *w = new SessionBaseWindow(this);
    {
        QLabel *b = new QLabel;
        b->setText("setLeftBottomWidget");
        b->setStyleSheet("border:2px solid red;");
        w->setLeftBottomWidget(b);
    }
    {
        QLabel *b = new QLabel;
        b->setText("setCenterBottomWidget");
        b->setStyleSheet("border:2px solid red;");
        w->setCenterBottomWidget(b);
    }
    {
        QLabel *b = new QLabel;
        b->setText("setRightBottomWidget");
        b->setStyleSheet("border:2px solid red;");
        w->setRightBottomWidget(b);
    }
    {
        QLabel *b = new QLabel;
        b->setText("setCenterContent");
        b->setStyleSheet("border:2px solid red;");
        w->setCenterContent(b);
    }
    {
        QLabel *b = new QLabel;
        QWidget *a = new TimeWidget;
        b->setText("setCenterTopWidget");
        b->setStyleSheet("border:2px solid red;");
        w->setCenterTopWidget(a);
    }

    m_mainLayou->addWidget(w);

    QWidget *widget = new QWidget;
    widget->setLayout(m_mainLayou);
    setCentralWidget(widget);
    initSystemTray();
}

MainWindow::~MainWindow()
{

}

void MainWindow::closeEvent(QCloseEvent *event)
{
    hide();
    event->ignore();
}

void MainWindow::initSystemTray()
{
    m_systemTray = new TrayMenu;

    m_systemTray ->setToolTip(QString("this is system tray"));
    m_systemTray ->setIcon(QIcon(":/img/attention"));
    connect(m_systemTray , SIGNAL(activated(QSystemTrayIcon::ActivationReason)), this, SLOT(iconIsActived(QSystemTrayIcon::ActivationReason)));

    m_systemTray->show();

    //������ʾ��ʾ��Ϣ
    m_systemTray->showMessage(QString("this is title"), QString("this is content"));
}

void MainWindow::iconIsActived(QSystemTrayIcon::ActivationReason reason)
{
    switch(reason)
      {
      //���������ʾ����
      case QSystemTrayIcon::Trigger:
       {
         showNormal();
         break;
       }
      //˫��������ʾ����
      case QSystemTrayIcon::DoubleClick:
      {
        showNormal();
        }
    }

}
