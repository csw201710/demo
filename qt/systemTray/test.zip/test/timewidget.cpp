#include "timewidget.h"


#include <QVBoxLayout>
#include <QDateTime>
#include <QLabel>
#include <QSettings>

TimeWidget::TimeWidget(QWidget *parent)
    : QWidget(parent)
{
    m_timeLabel = new QLabel;
    m_timeLabel->setAlignment(Qt::AlignCenter);

    QPalette palette = m_timeLabel->palette();
    palette.setColor(QPalette::WindowText, Qt::red);
    m_timeLabel->setPalette(palette);

    m_dateLabel = new QLabel;
    m_dateLabel->setAlignment(Qt::AlignCenter);
    palette = m_dateLabel->palette();
    palette.setColor(QPalette::WindowText, Qt::red);
    m_dateLabel->setPalette(palette);


    refreshTime();

    m_refreshTimer = new QTimer(this);
    m_refreshTimer->setInterval(1000);
    m_refreshTimer->start();

    QVBoxLayout *vLayout = new QVBoxLayout;
    vLayout->addWidget(m_timeLabel);
    vLayout->addWidget(m_dateLabel);
    vLayout->setSpacing(0);
    vLayout->setContentsMargins(0, 0, 0, 0);

    setLayout(vLayout);

    connect(m_refreshTimer, &QTimer::timeout, this, &TimeWidget::refreshTime);
}

void TimeWidget::set24HourFormat(bool use24HourFormat)
{
    m_use24HourFormat = use24HourFormat;
    refreshTime();
}



void TimeWidget::refreshTime()
{
    if (m_use24HourFormat) {
        m_timeLabel->setText(m_locale.toString(QDateTime::currentDateTime(), "hh:mm:ss"));
    } else {
        m_timeLabel->setText(m_locale.toString(QDateTime::currentDateTime(), "hh:mm:ss ap"));
    }

    m_dateLabel->setText(m_locale.toString(QDateTime::currentDateTime(), "yyyy-MM-dd dddd"));
}
