#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include "traymenu.h"
#include <QSystemTrayIcon>
#include <QCloseEvent>
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void closeEvent( QCloseEvent *event );

public slots:
    void iconIsActived(QSystemTrayIcon::ActivationReason reason);
private:
    void initSystemTray();


private:
    QVBoxLayout *m_mainLayou;
    QSystemTrayIcon *m_systemTray ;
};

#endif // MAINWINDOW_H
