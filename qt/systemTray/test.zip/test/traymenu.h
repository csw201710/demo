#ifndef TRAYMENU_H
#define TRAYMENU_H

#include <QObject>
#include <QWidget>
#include <QSystemTrayIcon>
#include <QAction>
#include <QMenu>
class TrayMenu : public QSystemTrayIcon
{
    Q_OBJECT
public:
    explicit TrayMenu(QWidget *parent = 0);

private:
    void createActions();


private:
    QAction* action_show;
    QAction* action_help;
    QAction* action_about;
    QMenu*   tray_menu;
};

#endif // TRAYMENU_H
