#ifndef TESTDIALOG_H
#define TESTDIALOG_H

#include <QWidget>
#include <QDialog>

class TestDialog : public QDialog
{
public:
    TestDialog();
};

#endif // TESTDIALOG_H
